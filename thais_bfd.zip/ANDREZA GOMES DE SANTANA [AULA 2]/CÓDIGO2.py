num1 = 10
num2 = 20
soma = num1 + num2
print("O resultado da soma é", soma)
#Saída: O resultado da soma é 30 
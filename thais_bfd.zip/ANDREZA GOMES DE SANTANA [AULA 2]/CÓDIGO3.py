nome_usuario = input("Qual é o seu nome?")
print("Prazer em te conhecer,", nome_usuario)
#Saída esperada: Prazer em te conhecer, Bruno.
email_usuario = input("Digite seu e-mail: ")
print(email_usuario)
# Saída esperada: brunoantonio0210@gmail.com

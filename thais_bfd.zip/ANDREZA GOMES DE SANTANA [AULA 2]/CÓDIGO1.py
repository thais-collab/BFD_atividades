nome = "Maria"
idade = 30
print("Olá, mundo!")
print("Seu nome é:", nome)
print("Você tem", idade, "anos.") 


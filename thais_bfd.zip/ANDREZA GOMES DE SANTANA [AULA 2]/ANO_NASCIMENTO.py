ANO_ATUAL = 2025
ano_nascimento = int(input("Digite o ano de nasciento:"))

print(f"Você tem {ANO_ATUAL - ano_nascimento}")

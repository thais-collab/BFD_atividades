a = 10
b = 3

resultado_and = (a > 5) and (b < 5)
resultado_or = (a > 15) or (b < 5)
resultado_not = not (a > 5)

print (f'(a > 5) and (b< 5): {resultado_and}' +
       f'\n(a > 5) or (b < 5): {resultado_or}' +
       f'\nnot(a > 5): {resultado_not}')


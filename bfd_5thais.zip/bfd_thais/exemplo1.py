import random

semaforo = random.choice(['vermelho', 'amarelo', 'verde'])

if semaforo == 'vermelho':
    print('não passe...')
elif semaforo == 'amarelo':
    print('pode passar,porém tenha cuidado...')
else:
    print('pode passar...')
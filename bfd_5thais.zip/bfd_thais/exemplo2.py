idade = int(input("Digite sua idade:"))

if idade >= 18:
    print("Usuario maior de idade")
else:
    print("voce e menor de idade")
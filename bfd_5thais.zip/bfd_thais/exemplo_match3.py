comidas = 'Lasanha'

match comidas:
    case "Lasanha":
        print(" Que lasanha gostosa...")
    case "pirão":
        print("Que pirão gostoso...")
    case "stogonoff":
        print("Que strogonoff gostoso...")
    case "feijão carioca":
        print("Que feijão carioca gostoso") 
    case _ :
        print("Comando Invalido")           

    
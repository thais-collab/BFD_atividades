Variavel = 0
while Variavel < 10:
    print(Variavel)
    input()
    Variavel += 1
estoque = ["camiseta", "calça", "meia", "jaqueta"]
print(estoque)

del estoque[1]
print("O estoque do produto calça esgotou", estoque)

estoque.append('boné')
print("Chegou um novo item ao estoque,agora temos bonés", estoque)

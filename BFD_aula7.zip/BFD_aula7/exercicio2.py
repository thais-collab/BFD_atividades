Alunos = ["Bruno", "Ana", "Carlos", "Denise", "Felipe"]
print(Alunos)

Alunos.reverse()
print(Alunos)

print(Alunos[0])
print(Alunos.index("Felipe"))

print(Alunos[3])
print(Alunos.index("Ana"))
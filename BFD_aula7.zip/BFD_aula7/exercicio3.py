# TUPLA

funcionario = ("Ana Souza", "Gerente", 8500)
print(funcionario)
print(funcionario[0])
print(funcionario[1])
print(funcionario[2])


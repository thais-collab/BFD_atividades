dividendo = int(input("Digite o dividendo: "))
divisor = int(input("Digite o divisor: "))

resultado = dividendo // divisor 
resto = dividendo % divisor 

print(f"{dividendo}) / {divisor} = {resultado} | resto = {resto}")
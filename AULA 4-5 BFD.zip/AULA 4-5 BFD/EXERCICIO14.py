
esta_chovendo = True

nao_esta_chovendo = not esta_chovendo

print(f"esta_chovendo = {esta_chovendo}")
print(f"nao_esta_chovendo = {nao_esta_chovendo}")

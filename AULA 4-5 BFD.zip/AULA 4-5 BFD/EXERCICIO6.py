numero = 2
expoente = int(input("Digite o expoente:"))

print(f"Valor inicial de numero:{numero}")

numero **= expoente
print(f"Valor final de numero:{numero}")
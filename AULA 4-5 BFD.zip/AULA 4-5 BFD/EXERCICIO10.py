valor1 = 10.50
valor2 = 12.00


resultado = valor1 != valor2


print(f"{valor1} é diferente de {valor2}? {resultado}")

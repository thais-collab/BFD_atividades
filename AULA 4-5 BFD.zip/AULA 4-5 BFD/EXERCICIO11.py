IDADE_MINIMA = 18


idade_usuario = int(input("Digite sua idade: "))


maior_idade = idade_usuario >= IDADE_MINIMA
menor_idade = idade_usuario < IDADE_MINIMA


print(f"O usuário é maior de idade? {maior_idade}")
print(f"O usuário é menor de idade? {menor_idade}")

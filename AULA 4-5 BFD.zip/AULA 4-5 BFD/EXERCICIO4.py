num1 = int(input("Digite um valor inteiro: "))
num2 =  int(input("Digite outro valor inteiro"))
POTENCIA = num1 ** num2

DIVISAO_INTEIRA = num1 // num2
RESTO = num1 % num2

print(f"{num1} ** {num2} = {POTENCIA}")
print(f"{num1} // {num2} = {DIVISAO_INTEIRA}")
print(f"{num1} % {num2} = {RESTO}")
#valido = False
#while valido != True:
 #   nota = float(input("Digite uma nota entre 0 e 10: "))
  #  if nota < 0 or nota > 10:
   #  print("Valor invalido!")
#else:
 #   print("Nota valida!")
  #  print(f"A nota informado foi:{nota}")
   # valido = True
   
#nota = -1
#while nota < 0 and > 10:

#while True:
#    nota = float(input("Digite uma nota entre 0 e 10:"))
  #  if nota >= 0 and nota <= 10:
    #    print(f"A nota informada foi: {nota}") 
      #  break
   # print(f"Nota invalida!")
nome_usuario = ""
senha_usuario = ""

while nome_usuario == senha_usuario:
 nome_usuario = input("Digite o nome do usuario: ")
 senha_usuario = input("Digite a sua senha: ")
 if nome_usuario == senha_usuario:
     print("Error: O valor passado no bloco USUARIO, e no bloco SENHA não podem ser iguais.")



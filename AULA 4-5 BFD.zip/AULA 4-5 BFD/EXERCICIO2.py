num1 = int(input("Digite o primeiro número:"))
num2 = int(input("Digite o segundo número:"))
multiplicacao = num1 * num2
divisao = num1 / num2
print("O resultado da multiplicação dos dois números é:",multiplicacao)
print("e a divisão dos mesmos valores é:", divisao)
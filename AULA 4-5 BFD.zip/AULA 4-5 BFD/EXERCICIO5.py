estoque = 50 
valor = int(input("Digite a quantidade a ser adicionada ao estoque:"))

print(f"estoque inicial = {estoque}")
estoque += valor 
print(f"estoque final: {estoque}")
nome_a = "Python"
nome_b = "python"


resultado = nome_a == nome_b


print(f"{nome_a} é igual ao {nome_b}? {resultado}")
saldo_bancario = 1000

deposito = float(input("Digite o valor do deposito:"))
saque = float(input("Digite o valor do saque:"))
fator_juros = float(input("Digite o fator de juros(exemplo: 1.05 para 5% de aumento)"))

saldo_bancario += deposito
print(f"Após depósito: {saldo_bancario}")

saldo_bancario -= saque
print(f"Após o saque: {saldo_bancario}")

saldo_bancario *= fator_juros
print(f"Após aplicação de juros: {saldo_bancario}")

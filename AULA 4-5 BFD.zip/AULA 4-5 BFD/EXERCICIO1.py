numero_1 = int(input ("Digite o primeiro numero da soma:"))
numero_2 = int(input ("Digite o segundo numero da soma:"))
Soma =  numero_1 + numero_2
print(f"O resultado da soma foi:", Soma)

num_1 = int(input ("Digite o primeiro número da subtração:"))
num_2 = int(input ("Digite o segundo número da subtração:"))
Subtracao = num_1 - num_2
print(f"O resultado da subtração foi:", Subtracao)

# Tudo ok!
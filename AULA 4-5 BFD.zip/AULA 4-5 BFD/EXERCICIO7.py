tarefas = 20

numero_pessoas = int(input("Digite a quantidade de pessoas:"))
tarefas //= numero_pessoas
print(f"a quantidade de tarefas para cada pessoa é: {tarefas}")